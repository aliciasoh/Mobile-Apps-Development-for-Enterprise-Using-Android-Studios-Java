package com.beardedhen.androidbootstrap.api.attributes;

public enum ViewGroupPosition {
    SOLO,
    MIDDLE_HORI,
    MIDDLE_VERT,
    TOP,
    BOTTOM,
    START,
    END
}