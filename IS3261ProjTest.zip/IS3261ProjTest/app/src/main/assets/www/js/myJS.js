
document.getElementById("dropDownList").addEventListener("change",
  function(){
	  item = document.getElementById("dropDownList").value;
	  switch(item) {
		case "Introduction":
		   document.getElementById("JSONText").innerHTML ="Silver Ribbon Coalition was founded by Jean Singleton Liechty, J. D. in 1993 (www.silverribbon.org). With her kind consent, Silver Ribbon (Singapore) registered with Registry of Singapore on 21 Dec 2005 (ROS No 2210/2005) and invited the then President, S R Nathan, to grace its official launch on 4 Feb 2006.";
		   break;
		case "Vision & Mission":
		   document.getElementById("JSONText").innerHTML ="Our Vision: " + "\n" + "Positive attitude towards mental health among the community." + "\n" + "Our Mission: " + "\n" + "To combat mental health stigma, encourage early treatment, and facilitate integration of people with mental illness within the society through innovative means of promoting mental health literacy.";
		   break;
		case "Types of Disorders":
			document.getElementById("JSONText").innerHTML ="Delirium, Dementia, and Other Cognitive Disorders, Substance-Related Disorders, Psychotic Disorders and Schizophrenia, Mood Disorders, Anxiety Disorders, Eating Disorders, Impulse-Control Disorders, Sleep Disorders, Personality Disorders, Childhood Disorders";
			break;
		default:
			document.getElementById("JSONText").innerHTML ="Click on drop down menu";
			break;
	  }
  }, true);
