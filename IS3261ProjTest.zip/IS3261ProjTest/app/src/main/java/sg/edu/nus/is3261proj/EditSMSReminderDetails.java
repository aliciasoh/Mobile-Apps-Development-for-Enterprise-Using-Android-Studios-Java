package sg.edu.nus.is3261proj;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class EditSMSReminderDetails extends Activity {

    EditText EditSMSNumber;
    EditText EditSMSText;
    TextView SMSTime;
    TextView SMSDate;
    private Button setNewDate;
    private Button setNewTime;

    private int mYear;
    private int mMonth;
    private int mDay;

    static final int DATE_DIALOG_ID = 0;

    private int mHour;
    private int mMinute;

    static final int TIME_DIALOG_ID = 1;

    MyDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_smsreminder_details);

        EditSMSNumber = (EditText) findViewById(R.id.updateSMSNumberReminder);
        EditSMSText = (EditText) findViewById(R.id.updateSMSTextReminder);
        SMSDate = (TextView) findViewById(R.id.newDateText);
        SMSTime = (TextView) findViewById(R.id.newTimeText);
        setNewDate = (Button) findViewById(R.id.setNewDate);
        setNewTime = (Button) findViewById(R.id.setNewTime);



        String number = getIntent().getStringExtra("number");
        String textDetails = getIntent().getStringExtra("text");
        String moreDetails = getIntent().getStringExtra("textDetails");
        String idNumber = getIntent().getStringExtra("idNumber");

        //text details substring
        int textIndex = textDetails.indexOf("Text:");
        String substrText=textDetails.substring(textIndex + 6);


        //time substring
        int timeIndex = moreDetails.indexOf("Time");
        String substrTime=moreDetails.substring(timeIndex);
        SMSTime.setText(substrTime);

        //time substring with new line
        int timeNewIndex = moreDetails.indexOf("\nTime");

        //date substring
        int dateIndex = moreDetails.indexOf("Date");
        String substrDate = moreDetails.substring(dateIndex, timeNewIndex);
        SMSDate.setText(substrDate);

        db = new MyDB(this);

        EditSMSNumber.setText(number, TextView.BufferType.EDITABLE);
        EditSMSText.setText(substrText, TextView.BufferType.EDITABLE);

        // add a click listener to the button
        setNewDate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showDialog(DATE_DIALOG_ID);
            }
        });

        // get the current date
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        // add a click listener to the button
        setNewTime.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showDialog(TIME_DIALOG_ID);
            }
        });

        // get the current time
        Calendar d = Calendar.getInstance();
        mHour = d.get(Calendar.HOUR_OF_DAY);
        mMinute = d.get(Calendar.MINUTE);

        // display the current date (this method is below)
        updateDisplay();

    }

    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DATE_DIALOG_ID:
                return new DatePickerDialog(this,
                        mDateSetListener,
                        mYear, mMonth, mDay);

            case TIME_DIALOG_ID:
                return new TimePickerDialog(this,
                        mTimeSetListener, mHour, mMinute, false);
        }
        return null;
    }


    // updates the date we display in the TextView
    private void updateDisplay() {
        SMSDate.setText("Date set: " +
                new StringBuilder()
                        // Month is 0 based so add 1
                        .append(mMonth + 1).append("-")
                        .append(mDay).append("-")
                        .append(mYear).append(" "));

        SMSTime.setText("Time set: " +
                new StringBuilder()
                        .append(pad(mHour)).append(":")
                        .append(pad(mMinute)));
    }

    // the callback received when the user "sets" the time in the dialog
    private TimePickerDialog.OnTimeSetListener mTimeSetListener =
            new TimePickerDialog.OnTimeSetListener() {
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    mHour = hourOfDay;
                    mMinute = minute;
                    updateDisplay();
                }
            };

    private static String pad(int d) {
        if (d >= 10)
            return String.valueOf(d);
        else
            return "0" + String.valueOf(d);
    }

    // the callback received when the user "sets" the date in the dialog
    private DatePickerDialog.OnDateSetListener mDateSetListener =
            new DatePickerDialog.OnDateSetListener() {
                public void onDateSet(DatePicker view, int year,
                                      int monthOfYear, int dayOfMonth) {
                    mYear = year;
                    mMonth = monthOfYear;
                    mDay = dayOfMonth;
                    updateDisplay();
                }
            };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_edit_smsreminder_details, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    String numberChanged;
    String textChanged;
    String dateChanged;
    String timeChanged;

    public void updateSMSRecord(View view){

        numberChanged = EditSMSNumber.getText().toString();
        textChanged = EditSMSText.getText().toString();
        dateChanged = SMSDate.getText().toString();
        timeChanged = SMSTime.getText().toString();

        String idNumber = getIntent().getStringExtra("idNumber");

        db.open();
        db.updateSMSRecord(idNumber, numberChanged, textChanged, dateChanged, timeChanged);
        db.close();

        Toast.makeText(getApplicationContext(), "Reminder Changed!", Toast.LENGTH_LONG).show();

        //Set alarm to ring
        Calendar cal = Calendar.getInstance();
        cal.set(mYear,
                mMonth,
                mDay,
                mHour,
                mMinute,
                00);

        setAlarm(cal);


        Intent i = new Intent(this, MainMenu.class);
        i.putExtra("details", "Record: " + idNumber + "\n" + "Number: " + numberChanged  + "\n" + "Text: " + textChanged  + "\n" +  dateChanged+ "\n" + timeChanged);
        i.putExtra("idNumber", idNumber);
        this.startActivity(i);

    }

    final static int RQS_1 = 1;

    private void setAlarm(Calendar targetCal){

        numberChanged = EditSMSNumber.getText().toString();
        textChanged = EditSMSText.getText().toString();

        Intent intent = new Intent(getBaseContext(), SMSReceiver.class);

        intent.putExtra("numbertoSendNow", numberChanged);
        intent.putExtra("texttoSendNow", textChanged);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(getBaseContext(), RQS_1, intent, 0);
        AlarmManager alarmManager = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, targetCal.getTimeInMillis(), pendingIntent);
    }

}
