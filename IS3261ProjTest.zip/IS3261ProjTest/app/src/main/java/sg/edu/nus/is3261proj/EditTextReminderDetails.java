package sg.edu.nus.is3261proj;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;

public class EditTextReminderDetails extends Activity {
    EditText textToEdit;

    private TextView newDateText;
    private Button setNewDate;

    private int mYear;
    private int mMonth;
    private int mDay;

    static final int DATE_DIALOG_ID = 0;

    private TextView newTimeText;
    private Button setNewTime;

    private int mHour;
    private int mMinute;

    static final int TIME_DIALOG_ID = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_text_reminder_details);

        String title = getIntent().getStringExtra("title");
        String details = getIntent().getStringExtra("details");
        String idNumber = getIntent().getStringExtra("idNumber");

        db = new MyDB(this);

        textToEdit = (EditText)findViewById(R.id.updateTextReminder);
        textToEdit.setText(title, TextView.BufferType.EDITABLE);

        // capture our View elements
        newDateText = (TextView) findViewById(R.id.newDateText);
        setNewDate = (Button) findViewById(R.id.setNewDate);


        // add a click listener to the button
        setNewDate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showDialog(DATE_DIALOG_ID);
            }
        });

        // get the current date
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        // capture our View elements
        newTimeText = (TextView) findViewById(R.id.newTimeText);
        setNewTime = (Button) findViewById(R.id.setNewTime);


        //time substring
        int timeIndex = details.indexOf("Time");
        String substrTime=details.substring(timeIndex);
        newTimeText.setText(substrTime);

        //date substring
        int dateIndex = details.indexOf("Date");
        String substrDate = details.substring(dateIndex, timeIndex);
        newDateText.setText(substrDate);



        // add a click listener to the button
        setNewTime.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showDialog(TIME_DIALOG_ID);
            }
        });

        // get the current time
        Calendar d = Calendar.getInstance();
        mHour = d.get(Calendar.HOUR_OF_DAY);
        mMinute = d.get(Calendar.MINUTE);

        // display the current date (this method is below)
        updateDisplay();
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DATE_DIALOG_ID:
                return new DatePickerDialog(this,
                        mDateSetListener,
                        mYear, mMonth, mDay);

            case TIME_DIALOG_ID:
                return new TimePickerDialog(this,
                        mTimeSetListener, mHour, mMinute, false);
        }
        return null;
    }


    // updates the date we display in the TextView
    private void updateDisplay() {
        newDateText.setText("Date set: " +
                new StringBuilder()
                        // Month is 0 based so add 1
                        .append(mMonth + 1).append("-")
                        .append(mDay).append("-")
                        .append(mYear).append(" "));

        newTimeText.setText("Time set: " +
                new StringBuilder()
                        .append(pad(mHour)).append(":")
                        .append(pad(mMinute)));
    }

    // the callback received when the user "sets" the time in the dialog
    private TimePickerDialog.OnTimeSetListener mTimeSetListener =
            new TimePickerDialog.OnTimeSetListener() {
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    mHour = hourOfDay;
                    mMinute = minute;
                    updateDisplay();
                }
            };

    private static String pad(int d) {
        if (d >= 10)
            return String.valueOf(d);
        else
            return "0" + String.valueOf(d);
    }

    // the callback received when the user "sets" the date in the dialog
    private DatePickerDialog.OnDateSetListener mDateSetListener =
            new DatePickerDialog.OnDateSetListener() {
                public void onDateSet(DatePicker view, int year,
                                      int monthOfYear, int dayOfMonth) {
                    mYear = year;
                    mMonth = monthOfYear;
                    mDay = dayOfMonth;
                    updateDisplay();
                }
            };

    String textString;
    String dateString;
    String timeString;

    public void updateRecord(View view){

        textString = textToEdit.getText().toString();
        dateString = newDateText.getText().toString();
        timeString = newTimeText.getText().toString();

        String idNumber = getIntent().getStringExtra("idNumber");

        db.open();
        db.updateRecord(idNumber, textString, dateString, timeString);
        db.close();

        Toast.makeText(getApplicationContext(), "Reminder Changed!", Toast.LENGTH_LONG).show();

        //Set alarm to ring
        Calendar cal = Calendar.getInstance();
        cal.set(mYear,
                mMonth,
                mDay,
                mHour,
                mMinute,
                00);

        setAlarm(cal);


        Intent i = new Intent(this, MainMenu.class);
        i.putExtra("title", textString);
        i.putExtra("details", "Record: " + idNumber + "\n" + dateString + "\n" + timeString);
        this.startActivity(i);

    }

    final static int RQS_1 = 1;

    private void setAlarm(Calendar targetCal){

        Intent intent = new Intent(getBaseContext(), AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getBaseContext(), RQS_1, intent, 0);
        AlarmManager alarmManager = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, targetCal.getTimeInMillis(), pendingIntent);
    }

    MyDB db;

    public ArrayList<String[]> getAllRecords(){
        db.open();
        Cursor c = db.getAllRecords();

        ArrayList<String[]> records = new ArrayList<String[]>();

        if(c.moveToFirst()){
            do {
                String[] record = {
                        c.getString(0), c.getString(1), c.getString(2), c.getString(3)};
                records.add(record);
            } while (c.moveToNext());
        }
        db.close();
        return records;
    }

}
