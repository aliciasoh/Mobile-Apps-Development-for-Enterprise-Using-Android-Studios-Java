package sg.edu.nus.is3261proj;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class LocationReminderDetails extends Activity {

    MyDB db;
    TextView locationTitle;
    TextView locationAddressDetails;

    Button readLocation;
    TextToSpeech t1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_reminder_details);

        db = new MyDB(this);

        locationTitle = (TextView) findViewById(R.id.locationTitle);
        locationAddressDetails = (TextView) findViewById(R.id.locationDetails);

        Intent intent = getIntent();
        String title  = intent.getStringExtra("title");
        String details  = intent.getStringExtra("details");

        locationTitle.setText(title);
        locationAddressDetails.setText(details);

        readLocation=(Button)findViewById(R.id.readLocationReminder);


        t1=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status != TextToSpeech.ERROR) {
                    t1.setLanguage(Locale.US);
                }
            }
        });

        readLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String toSpeak = locationTitle.getText().toString() + "\n" + locationAddressDetails.getText().toString();
                Toast.makeText(getApplicationContext(), toSpeak, Toast.LENGTH_SHORT).show();

                t1.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);
            }
        });

    }


    public void onPause(){
        if(t1 !=null){
            t1.stop();
            t1.shutdown();
        }
        super.onPause();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_location_reminder_details, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    TextView deleteLocationDetails;

    public void deleteLocationRecord(View view){

        deleteLocationDetails = (TextView) findViewById(R.id.locationDetails);
        String deleteLocationDetailsString = deleteLocationDetails.getText().toString();

        int startIndex = deleteLocationDetailsString.indexOf("Record: ");
        int endIndex = deleteLocationDetailsString.indexOf("\n");
        String idNumber=deleteLocationDetailsString.substring(startIndex + 8, endIndex);

        db.open();
        db.deleteLocationRecord(idNumber);
        db.close();

        String context = Context.LOCATION_SERVICE;
        LocationManager locationManager = (LocationManager) getSystemService(context);
        Intent anIntent = new Intent("proximity");
        PendingIntent operation =
                PendingIntent.getBroadcast(getApplicationContext(), -1 , anIntent, 0);
        locationManager.removeProximityAlert(operation);

        Toast.makeText(getBaseContext(), "Deleted!",Toast.LENGTH_LONG).show();
        Intent i = new Intent(this, MainMenu.class);
        this.startActivity(i);

    }

    TextView editLocationTitle;
    TextView editLocationDetails;

    public void editLocationRecord(View view){

        editLocationTitle = (TextView) findViewById(R.id.locationTitle);
        String titleString = editLocationTitle.getText().toString();

        editLocationDetails = (TextView) findViewById(R.id.locationDetails);
        String locationString = editLocationDetails.getText().toString();

        int startIndex = locationString.indexOf("Record: ");
        int endIndex = locationString.indexOf("\n");
        String idNumber=locationString.substring(startIndex + 8, endIndex);

        int startLocationIndex = locationString.indexOf("Location:");
        String locationStringFinal=locationString.substring(startLocationIndex);

        db.open();
        Intent i = new Intent(this, EditLocationReminderDetails.class);
        i.putExtra("title", titleString);
        i.putExtra("details", locationStringFinal);
        i.putExtra("idNumber", idNumber);


        this.startActivity(i);
        db.close();


    }

}
