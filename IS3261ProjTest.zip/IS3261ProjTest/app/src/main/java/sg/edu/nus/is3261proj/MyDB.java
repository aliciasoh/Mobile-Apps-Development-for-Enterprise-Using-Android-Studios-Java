package sg.edu.nus.is3261proj;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * Created by Hp on 10/24/2015.
 */
public class MyDB {

    MyDBHelper DBHelper;
    SQLiteDatabase db;
    final Context context;

    public MyDB(Context ctx){
        this.context = ctx;
        DBHelper = new MyDBHelper(this.context);
    }

    public MyDB open(){
        db = DBHelper.getWritableDatabase();
        return this;
    }

    public void close(){
        DBHelper.close();
    }

    public long insertPhotoRecord(String photoReminderDetails, String s, String photoImageDetails){
        ContentValues initialValues = new ContentValues();
        initialValues.put(MyDBHelper.columnNamePhoto2, photoReminderDetails);
        initialValues.put(MyDBHelper.columnNamePhoto3, s);
        initialValues.put(MyDBHelper.columnNamePhoto4, photoImageDetails);


        long check = db.insert(MyDBHelper.tableNamePhoto, null, initialValues);

        return check;
    }

    public long insertSMSRecord(String SMSNumber, String SMSTextDetails, String Date, String Time){
        ContentValues initialValues = new ContentValues();
        initialValues.put(MyDBHelper.columnNameSMS2, SMSNumber);
        initialValues.put(MyDBHelper.columnNameSMS3, SMSTextDetails);
        initialValues.put(MyDBHelper.columnNameSMS4, Date);
        initialValues.put(MyDBHelper.columnNameSMS5, Time);


        long check = db.insert(MyDBHelper.tableNameSMS, null, initialValues);

        return check;
    }

    public long insertRecord(String textReminder, String date, String time){
        ContentValues initialValues = new ContentValues();
        initialValues.put(MyDBHelper.columnName2, textReminder);
        initialValues.put(MyDBHelper.columnName3, date);
        initialValues.put(MyDBHelper.columnName4, time);


        long check = db.insert(MyDBHelper.tableName, null, initialValues);

        return check;
    }

    public long insertLocationRecord(String locationText, String locationDetails){
        ContentValues initialValues = new ContentValues();
        initialValues.put(MyDBHelper.columnNameLocation2, locationText);
        initialValues.put(MyDBHelper.columnNameLocation3, locationDetails);

        long check = db.insert(MyDBHelper.tableNameLocation, null, initialValues);

        return check;
    }

    public String getIdNumber(String title){
        long recc=0;
        String rec=null;
        Cursor mCursor = db.rawQuery(
                "SELECT " + MyDBHelper.columnName1 + " FROM " + MyDBHelper.tableName + " WHERE " + MyDBHelper.columnName2 + " = '" + title + "'", null);
        if (mCursor != null)
        {
            mCursor.moveToFirst();
            recc=mCursor.getLong(0);
            rec=String.valueOf(recc);
        }
        return rec;
    }

    public String getPhotoIdNumber(String title){
        long recc=0;
        String rec=null;
        Cursor mCursor = db.rawQuery(
                "SELECT " + MyDBHelper.columnNamePhoto1 + " FROM " + MyDBHelper.tableNamePhoto + " WHERE " + MyDBHelper.columnNamePhoto2 + " = '" + title + "'", null);
        if (mCursor != null)
        {
            mCursor.moveToFirst();
            recc=mCursor.getLong(0);
            rec=String.valueOf(recc);
        }
        return rec;
    }

    public String getSMSIdNumber(String number){
        long recc=0;
        String rec=null;
        Cursor mCursor = db.rawQuery(
                "SELECT " + MyDBHelper.columnNameSMS1 + " FROM " + MyDBHelper.tableNameSMS + " WHERE " + MyDBHelper.columnNameSMS2 + " = '" + number + "'", null);
        if (mCursor != null)
        {
            mCursor.moveToFirst();
            recc=mCursor.getLong(0);
            rec=String.valueOf(recc);
        }
        return rec;
    }

    public String getLocationIdNumber(String number){
        long recc=0;
        String rec=null;
        Cursor mCursor = db.rawQuery(
                "SELECT " + MyDBHelper.columnNameLocation1 + " FROM " + MyDBHelper.tableNameLocation + " WHERE " + MyDBHelper.columnNameLocation2 + " = '" + number + "'", null);
        if (mCursor != null)
        {
            mCursor.moveToFirst();
            recc=mCursor.getLong(0);
            rec=String.valueOf(recc);
        }
        return rec;
    }

    public int deleteRecord(String idNumber){

        int check = db.delete(MyDBHelper.tableName, MyDBHelper.columnName1 + "='" + idNumber + "'", null);

        return check;

    }

    public int deleteSMSRecord(String idNumber){

        int check = db.delete(MyDBHelper.tableNameSMS, MyDBHelper.columnNameSMS1 + "='" + idNumber + "'", null);

        return check;

    }

    public int deletePhotoRecord(String idNumber){

        int check = db.delete(MyDBHelper.tableNamePhoto, MyDBHelper.columnNamePhoto1 + "='" + idNumber + "'", null);

        return check;

    }

    public int deleteLocationRecord(String idNumber){

        int check = db.delete(MyDBHelper.tableNameLocation, MyDBHelper.columnNameLocation1 + "='" + idNumber + "'", null);

        return check;

    }

    public byte[] getPhoto(String title){
        long recc=0;
        String rec=null;

        Cursor mCursor = db.rawQuery(
                "SELECT " + MyDBHelper.columnNamePhoto3 + " FROM " + MyDBHelper.tableNamePhoto + " WHERE " + MyDBHelper.columnNamePhoto2 + " = '" + title + "'", null);
        if (mCursor != null)
        {
            mCursor.moveToFirst();
            recc=mCursor.getLong(0);
            rec=String.valueOf(recc);
        }

        byte[] b = rec.getBytes();


        return b;

    }

    public int updateRecord(String idNumber, String textReminder, String date, String time) {

        ContentValues initialValues = new ContentValues();
        initialValues.put(MyDBHelper.columnName2, textReminder);
        initialValues.put(MyDBHelper.columnName3, date);
        initialValues.put(MyDBHelper.columnName4, time);

        int check = db.update(MyDBHelper.tableName, initialValues, MyDBHelper.columnName1 + "=" + idNumber, null);

        return check;
    }

    public int updateLocationRecord(String idNumber, String title, String location) {

        ContentValues initialValues = new ContentValues();
        initialValues.put(MyDBHelper.columnNameLocation2, title);
        initialValues.put(MyDBHelper.columnNameLocation3, location);

        int check = db.update(MyDBHelper.tableNameLocation, initialValues, MyDBHelper.columnNameLocation1 + "=" + idNumber, null);

        return check;
    }

    public int updatePhotoRecord(String idNumber, String photoTitle, String imageData, String photoDetails) {

        ContentValues initialValues = new ContentValues();
        initialValues.put(MyDBHelper.columnNamePhoto2, photoTitle);
        initialValues.put(MyDBHelper.columnNamePhoto3, imageData);
        initialValues.put(MyDBHelper.columnNamePhoto4, photoDetails);

        int check = db.update(MyDBHelper.tableNamePhoto, initialValues, MyDBHelper.columnNamePhoto1 + "=" + idNumber, null);

        return check;
    }

    public int updateSMSRecord(String idNumber, String number, String textDetails, String date, String time) {

        ContentValues initialValues = new ContentValues();
        initialValues.put(MyDBHelper.columnNameSMS2, number);
        initialValues.put(MyDBHelper.columnNameSMS3, textDetails);
        initialValues.put(MyDBHelper.columnNameSMS4, date);
        initialValues.put(MyDBHelper.columnNameSMS5, time);

        int check = db.update(MyDBHelper.tableNameSMS, initialValues, MyDBHelper.columnNameSMS1 + "=" + idNumber, null);

        return check;
    }

    public Cursor getAllRecords(){
        return db.query(
                MyDBHelper.tableName,
                new String[]{
                        MyDBHelper.columnName1,
                        MyDBHelper.columnName2,
                        MyDBHelper.columnName3,
                        MyDBHelper.columnName4},
                null,null,null,null,null);
    }

    public Cursor getAllPhotoRecords(){
        return db.query(
                MyDBHelper.tableNamePhoto,
                new String[]{
                        MyDBHelper.columnNamePhoto1,
                        MyDBHelper.columnNamePhoto2,
                        MyDBHelper.columnNamePhoto3,
                        MyDBHelper.columnNamePhoto4},
                null,null,null,null,null);
    }

    public Cursor getAllSMSRecords(){
        return db.query(
                MyDBHelper.tableNameSMS,
                new String[]{
                        MyDBHelper.columnNameSMS1,
                        MyDBHelper.columnNameSMS2,
                        MyDBHelper.columnNameSMS3,
                        MyDBHelper.columnNameSMS4,
                        MyDBHelper.columnNameSMS5},
                null,null,null,null,null);
    }

    public Cursor getAllLocationRecords(){
        return db.query(
                MyDBHelper.tableNameLocation,
                new String[]{
                        MyDBHelper.columnNameLocation1,
                        MyDBHelper.columnNameLocation2,
                        MyDBHelper.columnNameLocation3},
                null,null,null,null,null);
    }

}
