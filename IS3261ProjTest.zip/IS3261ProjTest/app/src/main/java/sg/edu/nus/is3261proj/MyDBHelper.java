package sg.edu.nus.is3261proj;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.util.Log;

public class MyDBHelper extends SQLiteOpenHelper {

    public	static	final	int databaseVersion	=	5;
    public	static	final	String	databaseName	="DatabaseName";


    public	static	final	String	tableName	="textReminderDB";
    public	static	final	String	columnName1	="idNumber";
    public	static	final	String	columnName2	="textReminder";
    public	static	final	String	columnName3	="Date";
    public	static	final	String	columnName4	="Time";

    private	static	final	String	SQLite_CREATE	=
            "CREATE	TABLE "	+	tableName	+	"( "	+	columnName1	+	" INTEGER PRIMARY KEY AUTOINCREMENT, "	+	columnName2	+	" TEXT NOT NULL, "	+	columnName3	+	" TEXT NOT NULL, " + columnName4 + " TEXT NOT NULL);";

    public	static	final	String	tableNamePhoto	="photoReminderDB";
    public	static	final	String	columnNamePhoto1	="idNumber";
    public	static	final	String	columnNamePhoto2	="photoTextReminder";
    public	static	final   String  columnNamePhoto3 ="photoImage";
    public	static	final	String	columnNamePhoto4	="photoDetails";

    private	static	final	String	SQLite_CREATE_tableNamePhoto	=
    "CREATE	TABLE "	+	tableNamePhoto	+	"( "	+	columnNamePhoto1	+	" INTEGER PRIMARY KEY AUTOINCREMENT, "	+	columnNamePhoto2	+	" TEXT NOT NULL, "	+	columnNamePhoto3	+	" TEXT NOT NULL, " + columnNamePhoto4 + " TEXT NOT NULL);";

    public	static	final	String	tableNameSMS	="SMSReminderDB";
    public	static	final	String	columnNameSMS1	="idNumber";
    public	static	final	String	columnNameSMS2	="SMSNumber";
    public	static	final   String  columnNameSMS3 ="SMSTextDetails";
    public	static	final	String	columnNameSMS4	="Date";
    public	static	final	String	columnNameSMS5	="Time";


    private	static	final	String	SQLite_CREATE_tableNameSMS	=
            "CREATE	TABLE "	+	tableNameSMS	+	"( "	+	columnNameSMS1	+	" INTEGER PRIMARY KEY AUTOINCREMENT, "	+	columnNameSMS2	+	" TEXT NOT NULL, "	+	columnNameSMS3	+	" TEXT NOT NULL, " + columnNameSMS4 + " TEXT NOT NULL, " + columnNameSMS5 + " TEXT NOT NULL);";

    public	static	final	String	tableNameLocation	="LocationReminderDB";
    public	static	final	String	columnNameLocation1	="idNumber";
    public	static	final	String	columnNameLocation2	="LocationReminderText";
    public	static	final   String  columnNameLocation3 ="LocationReminderAddress";


    private	static	final	String	SQLite_CREATE_tableNameLocation	=
            "CREATE	TABLE "	+	tableNameLocation	+	"( "	+	columnNameLocation1	+	" INTEGER PRIMARY KEY AUTOINCREMENT, "	+	columnNameLocation2	+	" TEXT NOT NULL, "	+	columnNameLocation3	+	" TEXT NOT NULL);";



    private	static final String	SQLite_DELETE	= "DROP	TABLE	IF	EXISTS	"	+	tableName;
    private	static final String	SQLite_DELETE_tableNamePhoto	= "DROP	TABLE	IF	EXISTS	"	+	tableNamePhoto;
    private	static final String	SQLite_DELETE_tableNameSMS	= "DROP	TABLE	IF	EXISTS	"	+	tableNameSMS;
    private	static final String	SQLite_DELETE_tableNameLocation	= "DROP	TABLE	IF	EXISTS	"	+	tableNameLocation;


    public MyDBHelper(Context context) {
        super(context, databaseName, null, databaseVersion);

    }

    @Override
    public	void onCreate(SQLiteDatabase db)	{
        db.execSQL(SQLite_CREATE);
        db.execSQL(SQLite_CREATE_tableNamePhoto);
        db.execSQL(SQLite_CREATE_tableNameSMS);
        db.execSQL(SQLite_CREATE_tableNameLocation);

    }
    @Override
    public	void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        //	note:	our	upgrade	policy	here	is	simply	to	discard	the	data	and	start	all	over
        db.execSQL(SQLite_DELETE);
        db.execSQL(SQLite_DELETE_tableNamePhoto);//	delete	the	existing	database
        db.execSQL(SQLite_DELETE_tableNameSMS);//	delete	the	existing	database
        db.execSQL(SQLite_DELETE_tableNameLocation);//	delete	the	existing	database

        onCreate(db);																															//	create	a	new	database
    }
}
