package sg.edu.nus.is3261proj;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.Locale;

public class PhotoReminderDetails extends Activity {

    TextView photoTitle;
    TextView photoDetails;
    ImageView photoImage;

    Button read;
    TextToSpeech t1;
    MyDB db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo_reminder_details);

        ScrollView scroller = new ScrollView(this);

        db= new MyDB(this);

        photoTitle = (TextView)findViewById(R.id.photoTitle);
        photoImage = (ImageView)findViewById(R.id.photoImage);
        photoDetails = (TextView)findViewById(R.id.photoDetails);

        Intent intent = getIntent();
        String title  = intent.getStringExtra("title");
        String details  = intent.getStringExtra("details");

        db.open();
        byte[] photoByte = db.getPhoto(title);
        Bitmap  bitmap = BitmapFactory.decodeByteArray(photoByte, 0, photoByte.length);

        BitmapFactory.Options bfo = new BitmapFactory.Options();
        bfo.inSampleSize = 4;
        bfo.outWidth = 150;
        bfo.outHeight = 150;

        int photoIndex = details.indexOf("/storage");
        int photoLastIndex = details.indexOf(".jpg");

        String photoPath=details.substring(photoIndex, photoLastIndex + 4);

        Bitmap photo = BitmapFactory.decodeFile(photoPath, bfo);
        Bitmap newPhoto = Bitmap.createScaledBitmap(photo, 500, 500, true);

        photoImage.setImageBitmap(newPhoto);
        photoTitle.setText(title);
        photoDetails.setText(details);

        read=(Button)findViewById(R.id.readReminder);

        t1=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status != TextToSpeech.ERROR) {
                    t1.setLanguage(Locale.US);
                }
            }
        });

        read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String toSpeak = photoTitle.getText().toString();
                Toast.makeText(getApplicationContext(), toSpeak, Toast.LENGTH_SHORT).show();
                t1.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);
            }
        });

        db.close();


    }

    public void onPause(){
        if(t1 != null){
            t1.stop();
            t1.shutdown();
        }
        super.onPause();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_photo_reminder_details, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    TextView photoDetails1;

    public void deletePhotoRecord(View view){

        photoDetails1 = (TextView)findViewById(R.id.photoDetails);
        String detailsString = photoDetails1.getText().toString();

        int startIndex = detailsString.indexOf("Record: ");
        int endIndex = detailsString.indexOf("\n");
        String idNumber=detailsString.substring(startIndex + 8, endIndex);


        db.open();
        db.deletePhotoRecord(idNumber);
        db.close();


        Toast.makeText(getBaseContext(), "Deleted!",Toast.LENGTH_LONG).show();
        Intent i = new Intent(this, MainMenu.class);
        this.startActivity(i);

    }

    public void editPhotoRecord(View view){


        photoTitle = (TextView)findViewById(R.id.photoTitle);
        photoImage = (ImageView)findViewById(R.id.photoImage);
        photoDetails = (TextView)findViewById(R.id.photoDetails);

        String photoTitleString = photoTitle.getText().toString();
        String photoDetailsString = photoDetails.getText().toString();


        int startIndex = photoDetailsString.indexOf("Record: ");
        int endIndex = photoDetailsString.indexOf("\n");
        String idNumber=photoDetailsString.substring(startIndex + 8, endIndex);

        int detailsStartIndex = photoDetailsString.indexOf("Captured Image");
        int detailsEndIndex = photoDetailsString.indexOf(".jpg");

        String detailsStringDetails=photoDetailsString.substring(detailsStartIndex, detailsEndIndex+4);

        db.open();

        Intent i = new Intent(this, EditPhotoReminderDetails.class);
        i.putExtra("title", photoTitleString);
        i.putExtra("details", detailsStringDetails);
        i.putExtra("idNumber", idNumber);

        this.startActivity(i);
        db.close();

    }




}
