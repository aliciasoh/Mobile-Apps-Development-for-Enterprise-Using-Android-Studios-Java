package sg.edu.nus.is3261proj;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by Hp on 11/3/2015.
 */
public class ProximityReceiver extends BroadcastReceiver {

    public static final String TAG = MapsActivity.class.getSimpleName();

    @Override
    public void onReceive(Context arg0, Intent intent) {

        showNotification(arg0);

        String k=LocationManager.KEY_PROXIMITY_ENTERING;
        // Key for determining whether user is leaving or entering

        boolean state=intent.getBooleanExtra(k, false);
        //Gives whether the user is entering or leaving in boolean form

        if(state){
            // Call the Notification Service or anything else that you would like to do here
            Toast.makeText(arg0, "You Have A Location Reminder From Forget Me Not!", Toast.LENGTH_LONG).show();

            String context = Context.LOCATION_SERVICE;
            LocationManager locationManager = (LocationManager) arg0.getSystemService(context);
            Intent anIntent = new Intent("proximity");
            PendingIntent operation =
                    PendingIntent.getBroadcast(arg0, -1 , anIntent, 0);
            locationManager.removeProximityAlert(operation);
        }


        Vibrator vibrator = (Vibrator) arg0.getSystemService(Context.VIBRATOR_SERVICE);
        vibrator.vibrate(10000);

        setResultCode(Activity.RESULT_OK);

        Uri alarmUri= RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);

       if (alarmUri == null) {
          alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        }
        final Ringtone ringtone = RingtoneManager.getRingtone(arg0, alarmUri);

        ringtone.play();

        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
           public void run() {
                if (ringtone.isPlaying())
                    ringtone.stop();
            }
        }, 5000);
    }


    private void showNotification(Context context) {
        PendingIntent contentIntent = PendingIntent.getActivity(context, 0,
                new Intent(context, LocationReminderMenu.class), 0);

        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(context)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("Forget Me Not")
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText("Location Reminder"))
                .setContentText("Click To View Notification");

        mBuilder.setContentIntent(contentIntent);
        mBuilder.setDefaults(Notification.DEFAULT_ALL);
        mBuilder.setAutoCancel(true);
        NotificationManager mNotificationManager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        mNotificationManager.notify(1, mBuilder.build());


    }


}