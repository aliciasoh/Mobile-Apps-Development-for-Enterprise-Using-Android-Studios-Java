package sg.edu.nus.is3261proj;

import android.app.Activity;
import android.content.Intent;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class SMSReminderDetails extends Activity {

    TextView SMSNumber;
    TextView SMSDetails;
    TextView SMSMoreDetails;

    MyDB db;
    Button readSMS;
    TextToSpeech t1;

    TextView deleteSMSNumber;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smsreminder_details);

        db = new MyDB(this);

        SMSNumber = (TextView) findViewById(R.id.SMSNumber);
        SMSDetails = (TextView) findViewById(R.id.SMSTextDetails);
        SMSMoreDetails = (TextView) findViewById(R.id.SMSTextMoreDetails);

        Intent intent = getIntent();
        String details  = intent.getStringExtra("details");

        //record substring
        int recordIndex = details.indexOf("Record:");
        int recordEndIndex = details.indexOf("\nNumber:");
        String substrrecord=details.substring(recordIndex, recordEndIndex);

        //number substring
        int numberIndex = details.indexOf("Number:");
        int numberEndIndex = details.indexOf("Text:");
        String substrNumber=details.substring(numberIndex, numberEndIndex);

        //text substring
        int textIndex = details.indexOf("Text:");
        int textEndIndex = details.indexOf("\nDate set:");
        String substrText=details.substring(textIndex, textEndIndex);

        //more text substring
        int moreTextIndex = details.indexOf("Date set:");
        String substrMoreText=details.substring(moreTextIndex);

        SMSNumber.setText(substrrecord + "\n" + substrNumber);

        SMSDetails.setText(substrText);

        SMSMoreDetails.setText(substrMoreText);

        readSMS=(Button)findViewById(R.id.readSMSReminder);


        t1=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status != TextToSpeech.ERROR) {
                    t1.setLanguage(Locale.US);
                }
            }
        });

        readSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String toRead = SMSDetails.getText().toString() + "\n" + SMSMoreDetails.getText().toString();
                Toast.makeText(getApplicationContext(), toRead, Toast.LENGTH_SHORT).show();

                t1.speak(toRead, TextToSpeech.QUEUE_FLUSH, null);
            }
        });

    }


    public void onPause(){
        if(t1 !=null){
            t1.stop();
            t1.shutdown();
        }
        super.onPause();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_smsreminder_details, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public void deleteSMSRecord(View view){

        deleteSMSNumber = (TextView) findViewById(R.id.SMSNumber);
        String deleteSMSNumberString = deleteSMSNumber.getText().toString();

        int recordStartIndex = deleteSMSNumberString.indexOf("Record: ");
        int recordEndIndex = deleteSMSNumberString.indexOf("\nNumber:");
        String SMSidNumber=deleteSMSNumberString.substring(recordStartIndex + 8, recordEndIndex);

        db.open();
        db.deleteSMSRecord(SMSidNumber);
        db.close();

        Toast.makeText(getBaseContext(), "Deleted!",Toast.LENGTH_LONG).show();
        Intent i = new Intent(this, MainMenu.class);
        this.startActivity(i);

    }

    TextView editNumber;
    TextView editText;
    TextView editDetails;

    public void editSMSRecord(View view){

        editNumber = (TextView) findViewById(R.id.SMSNumber);
        String numberString = editNumber.getText().toString();

        editText = (TextView) findViewById(R.id.SMSTextDetails);
        String textString = editText.getText().toString();

        editDetails = (TextView) findViewById(R.id.SMSTextMoreDetails);
        String moreDetailsString = editDetails.getText().toString();

        int recordStartIndex = numberString.indexOf("Record: ");
        int recordEndIndex = numberString.indexOf("\nNumber:");
        String SMSidNumber=numberString.substring(recordStartIndex + 8, recordEndIndex);

        int numberStartIndex = numberString.indexOf("Number: ");
        String SMSNumber=numberString.substring(numberStartIndex + 8);
        SMSNumber = SMSNumber.replaceAll("\\D+","");

        int textStartIndex = textString.indexOf("Text: ");
        String SMSText=textString.substring(textStartIndex + 6);

        db.open();

        Intent i = new Intent(this, EditSMSReminderDetails.class);
        i.putExtra("number", SMSNumber);
        i.putExtra("text", SMSText);
        i.putExtra("textDetails", moreDetailsString);
        i.putExtra("idNumber", SMSidNumber);


        this.startActivity(i);
        db.close();


    }

}
