package sg.edu.nus.is3261proj;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;

public class TextReminder extends Activity {

    EditText textToAdd;

    private TextView dateText;
    private Button setDate;

    private int mYear;
    private int mMonth;
    private int mDay;

    static final int DATE_DIALOG_ID = 0;

    private TextView timeText;
    private Button setTime;

    private int mHour;
    private int mMinute;

    static final int TIME_DIALOG_ID = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text_reminder);

        db = new MyDB(this);

        textToAdd = (EditText)findViewById(R.id.editTextReminder);

        // capture our View elements
        dateText = (TextView) findViewById(R.id.dateText);
        setDate = (Button) findViewById(R.id.setDate);

        // add a click listener to the button
        setDate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showDialog(DATE_DIALOG_ID);
            }
        });

        // get the current date
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        // capture our View elements
        timeText = (TextView) findViewById(R.id.timeText);
        setTime = (Button) findViewById(R.id.setTime);

        // add a click listener to the button
        setTime.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showDialog(TIME_DIALOG_ID);
            }
        });

        // get the current time
        Calendar d = Calendar.getInstance();
        mHour = d.get(Calendar.HOUR_OF_DAY);
        mMinute = d.get(Calendar.MINUTE);

        // display the current date (this method is below)
        updateDisplay();
    }

    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DATE_DIALOG_ID:
                return new DatePickerDialog(this,
                        mDateSetListener,
                        mYear, mMonth, mDay);

            case TIME_DIALOG_ID:
                return new TimePickerDialog(this,
                        mTimeSetListener, mHour, mMinute, false);
        }
        return null;
    }


    // updates the date we display in the TextView
    private void updateDisplay() {
        dateText.setText("Date set: " +
                new StringBuilder()
                        // Month is 0 based so add 1
                        .append(mMonth + 1).append("-")
                        .append(mDay).append("-")
                        .append(mYear).append(" "));

        timeText.setText("Time set: " +
                new StringBuilder()
                        .append(pad(mHour)).append(":")
                        .append(pad(mMinute)));
    }

    // the callback received when the user "sets" the time in the dialog
    private TimePickerDialog.OnTimeSetListener mTimeSetListener =
            new TimePickerDialog.OnTimeSetListener() {
                public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                    mHour = hourOfDay;
                    mMinute = minute;
                    updateDisplay();
                }
            };

    private static String pad(int d) {
        if (d >= 10)
            return String.valueOf(d);
        else
            return "0" + String.valueOf(d);
    }

    // the callback received when the user "sets" the date in the dialog
    private DatePickerDialog.OnDateSetListener mDateSetListener =
            new DatePickerDialog.OnDateSetListener() {
                public void onDateSet(DatePicker view, int year,
                                      int monthOfYear, int dayOfMonth) {
                    mYear = year;
                    mMonth = monthOfYear;
                    mDay = dayOfMonth;
                    updateDisplay();
                }
            };

    String textString;
    String dateString;
    String timeString;
    MyDB db;

    public void addRecord(View view){
        textString = textToAdd.getText().toString();
        dateString = dateText.getText().toString();
        timeString = timeText.getText().toString();

        db.open();
        db.insertRecord(textString, dateString, timeString);
        db.close();

        Toast.makeText(getApplicationContext(), "New Text Reminder Added!", Toast.LENGTH_LONG).show();

        //Set alarm to ring
        Calendar cal = Calendar.getInstance();
        cal.set(mYear,
                mMonth,
                mDay,
                mHour,
                mMinute,
                00);

            setAlarm(cal);

        Intent i = new Intent(this, MainMenu.class);
        startActivity(i);

    }

    final static int RQS_1 = 1;

    private void setAlarm(Calendar targetCal){

        Intent intent = new Intent(getBaseContext(), AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(getBaseContext(), RQS_1, intent, 0);
        AlarmManager alarmManager = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, targetCal.getTimeInMillis(), pendingIntent);


    }

    }
