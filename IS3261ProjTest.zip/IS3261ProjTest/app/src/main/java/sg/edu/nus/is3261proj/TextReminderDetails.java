package sg.edu.nus.is3261proj;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class TextReminderDetails extends Activity {

    TextView titleText;
    TextView detailsText;

    MyDB db;
    Button read;
    TextToSpeech t1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text_reminder_details);

        read=(Button)findViewById(R.id.readReminder);

        t1=new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status != TextToSpeech.ERROR) {
                    t1.setLanguage(Locale.US);
                }
            }
        });


        db = new MyDB(this);

        Intent intent = getIntent();
        String title  = intent.getStringExtra("title");

        String details  = intent.getStringExtra("details");

        titleText = (TextView) findViewById(R.id.title);
        titleText.setText(title);

        detailsText = (TextView) findViewById(R.id.details);
        detailsText.setText(details);

        read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String toSpeak = titleText.getText().toString() + "\n" + detailsText.getText().toString();
                Toast.makeText(getApplicationContext(), toSpeak, Toast.LENGTH_SHORT).show();
                t1.speak(toSpeak, TextToSpeech.QUEUE_FLUSH, null);
            }
        });
    }

    public void onPause(){
        if(t1 !=null){
            t1.stop();
            t1.shutdown();
        }
        super.onPause();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_text_reminder_details, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    TextView titleText1;
    SQLiteDatabase SQLiteDB;

    public void deleteRecord(View view){

        detailsText = (TextView) findViewById(R.id.details);
        String detailsString = detailsText.getText().toString();

        int startIndex = detailsString.indexOf("Record: ");
        int endIndex = detailsString.indexOf("\n");
        String idNumber=detailsString.substring(startIndex + 8, endIndex);

        db.open();
        db.deleteRecord(idNumber);
        db.close();


        Toast.makeText(getBaseContext(), "Deleted!",Toast.LENGTH_LONG).show();
        Intent i = new Intent(this, MainMenu.class);
        this.startActivity(i);

    }

    TextView detailsText1;

    public void editRecord(View view){

        titleText1 = (TextView) findViewById(R.id.title);
        String titleString = titleText1.getText().toString();

        detailsText1 = (TextView) findViewById(R.id.details);
        String detailsString = detailsText1.getText().toString();

        int startIndex = detailsString.indexOf("Record: ");
        int endIndex = detailsString.indexOf("\n");
        String idNumber=detailsString.substring(startIndex + 8, endIndex);

        int detailsStartIndex = detailsString.indexOf("Date set: ");
        String detailsStringDetails=detailsString.substring(detailsStartIndex);

        Intent i = new Intent(this, EditTextReminderDetails.class);
        i.putExtra("title", titleString);
        i.putExtra("details", detailsStringDetails);
        i.putExtra("idNumber", idNumber);


        this.startActivity(i);


    }


}
